import Carousel from "./Carousel"
import Navbar from "./Navbar"

const Layout = () => {
  return (
    <>
    <Navbar/>
    <Carousel/>
    {/* <Navbar/>
    <Navbar/>
    <Navbar/>
    <Navbar/>
    <Navbar/> */}
    </>
  )
}

export default Layout
